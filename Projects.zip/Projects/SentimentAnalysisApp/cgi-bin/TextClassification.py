from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, TfidfTransformer
from sklearn.naive_bayes import MultinomialNB

categories = {
 'alt.atheism':'Atheism',
 'comp.graphics':'Graphics',
 'comp.os.ms-windows.misc' : 'Computers',
 'comp.sys.ibm.pc.hardware':'Computers',
 'comp.sys.mac.hardware' : 'Computers',
 'comp.windows.x' : 'Computers',
 'misc.forsale' : 'Sale',
 'rec.autos' : 'Autos',
 'rec.motorcycles' : 'Motorcycles',
 'rec.sport.baseball' : 'Baseball',
 'rec.sport.hockey':'Hockey',
 'sci.crypt':'Cryptography',
 'sci.electronics' : 'Electronics',
 'sci.med' : 'Medical',
 'sci.space' : 'Space',
 'talk.politics.guns':'Guns',
 'talk.politics.misc' : 'Politics',
 'talk.religion.misc' : 'Religion'
}

dataset = fetch_20newsgroups(subset='train', categories=categories)

vect = CountVectorizer()
x_train = vect.fit_transform(dataset.data)

tfidf = TfidfTransformer()
x_train = tfidf.fit_transform(x_train)

clf = MultinomialNB()
clf.fit(x_train, dataset.target)

def test(input_data):
    input_data = [input_data]
    input_terms = vect.transform(input_data)
    input_terms = tfidf.transform(input_terms)
    y_pred = clf.predict(input_terms)
    pred = categories[dataset.target_names[y_pred[0]]]
    return pred