import SentimentAnalysis
import TextClassification
import summarizer
import cgi, smtplib

form = cgi.FieldStorage()

text = form.getvalue("text")
summary = summarizer.summarize(text)
sentiment = SentimentAnalysis.test(summary)
classification = TextClassification.test(text)

to = 'receiver_id'
gmail_user = 'sender_id'
gmail_pwd = 'sender_pwd'
smtpserver = smtplib.SMTP("smtp.gmail.com",587)
smtpserver.ehlo()
smtpserver.starttls()
smtpserver.ehlo
smtpserver.login(gmail_user, gmail_pwd)
header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject:Results \n'
msg = header + '\n {} {} {} \n\n'.format(summary, sentiment, classification)
smtpserver.sendmail(gmail_user, to, msg)
smtpserver.close()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <div class='summary' style='border:1px solid red;padding:10px;'>
        <h1>Summary is : </h1>
        <p>{}</p>
    </div>
    <h2>Class is : {}</h2>
    <h2>Sentiment is : {}</h2>
    <h3>Mail Sent to : {}</h3>
</div>
</body>
</html>
""".format(summary,classification,sentiment, to))