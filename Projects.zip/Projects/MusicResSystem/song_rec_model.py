import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv(r'music_dataset.csv')
X = df.drop(['title'], axis=1)
y = df['title']
def recommend_song(age, gender, mood):
    gender, age, mood = convert_value(gender, age, mood)
    current = [age, gender, mood]
    cosim = {}
    for i in range(len(df)):
        cosim[i] = (cosine_similarity(np.reshape(current, (1,-1)), X.iloc[i].values.reshape(1, -1)))
    rec_song = print_song(cosim)
    return rec_song


def print_song(cosim):
    rec_song = []
    top_score = sorted(cosim.items(), key=lambda x: x[1], reverse=True)
    for i in range(10):
         rec_song.append(y[top_score[i][0]])
    return rec_song

def convert_value(gender, age, mood):
    gender = 2 if 'Male' else 1
    mood_dict = {3:0, 0:1, 4:2, 1:3, 2:5, 5:6, 7:4}
    mood = mood_dict[mood]
    age_dict = {'(0-2)':0, '(4-6)':1, '(8-12)':2,'(15-20)':3, '(25-32)':5, '(38-43)':6, '(48-53)':7, '(60-100)':8}
    age = age_dict[age]
    return gender, age, mood

if __name__=='__main__':
    recommend_song('(15-20)','Male',3)
    
