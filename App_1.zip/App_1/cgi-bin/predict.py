import numpy as np
import pickle as pkl
import cgi

form = cgi.FieldStorage()
open_value = int(form.getvalue('open'))
high = int(form.getvalue('high'))
low = int(form.getvalue('low'))
close = int(form.getvalue('close'))

# file = open('weights.pkl', 'rb')
# theta = pkl.load(file)
# file.close()

file = open('model.pkl', 'rb')
theta = pkl.load(file)
file.close()

x_test_1 = np.array([[open_value, high, low, close]])
# prediction = np.dot(x_test_1, theta)

prediction = regression.predict(x_test_1)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Multiple Linear Regression Demo</h1>
    <hr>
    <h2>Prediction is {}</h2>

</body>
</html>
""".format(prediction))
