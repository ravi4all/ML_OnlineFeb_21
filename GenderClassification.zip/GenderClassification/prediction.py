import cv2
import numpy as np
import pickle as pkl

file = open('model.pkl', 'rb')
logistic = pkl.load(file)
file.close()

file = open('pca_model.pkl', 'rb')
pca = pkl.load(file)
file.close()
haar = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
def do_prediction():
    cap = cv2.VideoCapture('video_1.mp4')
    font = cv2.FONT_HERSHEY_COMPLEX
    while True:
        flag, img = cap.read()
        img = cv2.resize(img, None, fx=0.5, fy=0.5)
        faces = haar.detectMultiScale(img, 1.2)
        for x, y, w, h in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 4)
            face = img[y:y + h, x:x + w, :]
            face = cv2.resize(face, (60, 60))
            face = face / 255.
            face = np.reshape(1, -1)
            face = pca.transform([face])
            y_pred = logistic.predict(face)
            if y_pred[0] == 0:
                gender = 'male'
            else:
                gender = 'female'
            cv2.putText(img, gender, (x, y), font, 1.2, (255, 0, 0), 2)
        cv2.imshow('result', img)
        if cv2.waitKey(2) == 27:
            break

    cv2.destroyAllWindows()

def gender_clf(path):
    img = cv2.imread(path)
    faces = haar.detectMultiScale(img, 1.2)
    for x, y, w, h in faces:
        face = img[y:y + h, x:x + w, :]
        face = cv2.resize(face, (60, 60))
        face = face / 255.
        face = np.reshape(1, -1)
        face = pca.transform([face])
        y_pred = logistic.predict(face)
        if y_pred[0] == 0:
            gender = 'male'
        else:
            gender = 'female'
    return gender